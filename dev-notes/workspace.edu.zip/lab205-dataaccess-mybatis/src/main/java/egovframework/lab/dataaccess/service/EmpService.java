package egovframework.lab.dataaccess.service;

import java.math.BigDecimal;
import java.util.List;

public interface EmpService {
	
	// TODO [Step 3-1-2] EmpService 작성

}
