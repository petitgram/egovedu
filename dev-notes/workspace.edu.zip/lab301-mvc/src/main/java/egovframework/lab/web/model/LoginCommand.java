package egovframework.lab.web.model;

public class LoginCommand {

	// TODO [Step 1-2-3] LoginCommand.java 완성하기



}