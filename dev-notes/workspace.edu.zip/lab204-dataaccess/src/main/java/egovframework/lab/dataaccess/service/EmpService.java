package egovframework.lab.dataaccess.service;

import java.math.BigDecimal;
import java.util.List;

public interface EmpService {
    
    // TODO [Step 2-1] EmpService 작성

}
