package egovframework.lab.dataaccess.service;

import java.math.BigDecimal;

import egovframework.lab.dataaccess.common.SearchVO;

public class DeptVO extends SearchVO {

	// TODO [Step 3-2-1] DeptVO 작성

}
