package egovframework.lab.ioc.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.lab.ioc.service.EmpVO;

@Repository("annotationEmpDAO")
public class AnnotationEmpDAO {
    
    // TODO [Step 2-4] AnnotationEmpDAO 작성

}
