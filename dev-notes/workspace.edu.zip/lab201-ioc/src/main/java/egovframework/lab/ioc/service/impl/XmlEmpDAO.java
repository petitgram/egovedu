package egovframework.lab.ioc.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import egovframework.lab.ioc.service.EmpVO;

public class XmlEmpDAO {

    // TODO [Step 1-4] XmlEmpDAO 작성
    
}
