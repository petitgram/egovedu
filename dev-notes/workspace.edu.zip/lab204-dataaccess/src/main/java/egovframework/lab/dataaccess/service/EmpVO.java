package egovframework.lab.dataaccess.service;

import java.math.BigDecimal;
import java.util.Date;

public class EmpVO {

    // TODO [Step 2-2] EmpVO 작성
}
