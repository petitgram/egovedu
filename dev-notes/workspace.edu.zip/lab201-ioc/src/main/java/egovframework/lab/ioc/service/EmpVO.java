package egovframework.lab.ioc.service;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class EmpVO implements Serializable {

    // TODO [Step 1-2, 2-2] EmpVO 작성

}
