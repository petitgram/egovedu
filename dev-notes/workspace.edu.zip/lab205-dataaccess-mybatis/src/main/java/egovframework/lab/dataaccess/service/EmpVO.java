package egovframework.lab.dataaccess.service;

import java.math.BigDecimal;
import java.util.Date;

import egovframework.lab.dataaccess.common.SearchVO;

public class EmpVO extends SearchVO {
	
	// TODO [Step 3-1-1] EmpVO 작성

}
