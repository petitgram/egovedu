package egovframework.lab.ioc.service.impl;

import egovframework.lab.ioc.service.EmpService;

public class AnnotationEmpServiceImpl implements EmpService {
    
    // TODO [Step 2-3] AnnotationEmpServiceImpl 작성

}
