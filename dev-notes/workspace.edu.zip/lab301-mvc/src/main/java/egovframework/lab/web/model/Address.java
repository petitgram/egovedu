package egovframework.lab.web.model;

public class Address {

	private String address;
	private String addressDetail;

	public String getAddress() {
    	return address;
    }
	public void setAddress(String address) {
    	this.address = address;
    }
	public String getAddressDetail() {
    	return addressDetail;
    }
	public void setAddressDetail(String addressDetail) {
    	this.addressDetail = addressDetail;
    }


}
