package egovframework.lab.dataaccess.service.impl;

import java.math.BigDecimal;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egovframework.lab.dataaccess.service.EmpService;
import egovframework.lab.dataaccess.service.EmpVO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.fdl.idgnr.EgovIdGnrService;

@Service("empService")
public class EmpServiceImpl extends AbstractServiceImpl implements EmpService {
	
	// TODO [Step 3-1-3] EmpServiceImpl 작성

}
