package egovframework.lab.dataaccess.service;

import java.util.List;

public interface DeptService {

	// TODO [Step 3-2-2] DeptService 작성

}
