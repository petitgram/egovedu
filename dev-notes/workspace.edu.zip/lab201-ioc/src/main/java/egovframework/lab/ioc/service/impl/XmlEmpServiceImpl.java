package egovframework.lab.ioc.service.impl;

import egovframework.lab.ioc.service.EmpService;

public class XmlEmpServiceImpl implements EmpService {
    
    // TODO [Step 1-3] XmlEmpServiceImpl 작성
    
}
