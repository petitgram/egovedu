package egovframework.lab.ioc.service;

import java.util.List;

public interface EmpService {

    // TODO [Step 1-1, 2-1] EmpService 에 대한 CRUD 및 목록조회 비지니스 메서드 작성
    
}
