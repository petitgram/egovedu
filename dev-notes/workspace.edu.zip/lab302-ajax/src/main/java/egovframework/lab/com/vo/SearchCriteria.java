package egovframework.lab.com.vo;


public class SearchCriteria {
	
	private String searchEid;
	private String searchDid;
	private String searchName;
	
	public String getSearchEid() {
		return searchEid;
	}
	public void setSearchEid(String searchEid) {
		this.searchEid = searchEid;
	}
	public String getSearchDid() {
		return searchDid;
	}
	public void setSearchDid(String searchDid) {
		this.searchDid = searchDid;
	}
	public String getSearchName() {
		return searchName;
	}
	public void setSearchName(String searchName) {
		this.searchName = searchName;
	}	
}
